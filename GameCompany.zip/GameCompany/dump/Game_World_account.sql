-- MySQL dump 10.13  Distrib 5.7.12, for osx10.9 (x86_64)
--
-- Host: ix.cs.uoregon.edu    Database: Game_World
-- ------------------------------------------------------
-- Server version	5.6.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `login_name` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `account_info` varchar(45) DEFAULT NULL,
  `game_name` varchar(45) NOT NULL,
  `player_id` int(11) NOT NULL,
  PRIMARY KEY (`login_name`,`game_name`),
  KEY `fk_account_game1_idx` (`game_name`),
  KEY `fk_account_player1_idx` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('p10@hearthstone.com','hearthstone','registered 2016','Hearthstone',10),('p11@hearthstone.com','hearthstone','registered 2016','Hearthstone',11),('p11@worldwarcraft.com','worldwarcraft','registered 2015','WorldWarcraft',11),('p12@menghuanxiyou.com','menghuanxiyou','registered 2016','Menghuanxiyou',12),('p12@worldwarcraft.com','worldwarcraft','registered 2016','WorldWarcraft',12),('p13@hearthstone.com','hearthstone','registered 2008','Hearthstone',13),('p14@menghuanxiyou.com','menghuanxiyou','registered 2016','Menghuanxiyou',14),('p15@menghuanxiyou.com','menghuanxiyou','registered 2008','Menghuanxiyou',15),('p16@overwatch.com','overwatch','registered 2015','Overwatch',16),('p17@overwatch.com','overwatch','registered 2008','Overwatch',17),('p18@overwatch.com','overwatch','registered 2016','Overwatch',18),('p1@crossfire.com','crossfire','registered 2016','Crossfire',1),('p2@crossfire.com','crossfire','registered 2015','Crossfire',2),('p2@hearthstone.com','hearthstone','registered 2016','Hearthstone',2),('p2@overwatch.com','overwatch','registered 2015','Overwatch',2),('p3@crossfire.com','crossfire','registered 2016','Crossfire',3),('p4@crossfire.com','crossfire','registered 2016','Crossfire',4),('p4@menghuanxiyou.com','menghuanxiyou','registered 2008','Menghuanxiyou',4),('p5@crossfire.com','crossfire','registered 2016','Crossfire',5),('p5@dahuaxiyou.com','dahuaxiyou','registered 2008','Dahuaxiyou',5),('p6@dahuaxiyou.com','dahuaxiyou','registered 2016','Dahuaxiyou',6),('p6@worldwarcraft.com','worldwarcraft','registered 2008','WorldWarcraft',6),('p7@dahuaxiyou.com','dahuaxiyou','registered 2008','Dahuaxiyou',7),('p8@dnf.com','dnf','registered 2008','DNF',8),('p9@dnf.com','dnf','registered 2016','DNF',9);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-08 15:22:57
