-- MySQL dump 10.13  Distrib 5.7.12, for osx10.9 (x86_64)
--
-- Host: ix.cs.uoregon.edu    Database: Game_World
-- ------------------------------------------------------
-- Server version	5.6.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `login_time` datetime NOT NULL,
  `duration` varchar(45) NOT NULL,
  `purchase` varchar(45) DEFAULT NULL,
  `login_name` varchar(45) NOT NULL,
  `game_name` varchar(45) NOT NULL,
  PRIMARY KEY (`login_time`,`login_name`,`game_name`),
  KEY `fk_history_account1_idx` (`login_name`,`game_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
INSERT INTO `history` VALUES ('2016-01-01 18:00:00','3','100','p10@hearthstone.com','Hearthstone'),('2016-01-01 18:00:00','4','79','p11@hearthstone.com','Hearthstone'),('2016-01-01 18:00:00','8','100','p11@worldwarcraft.com','WorldWarcraft'),('2016-01-01 18:00:00','7','85','p12@menghuanxiyou.com','Menghuanxiyou'),('2016-01-01 18:00:00','6','46','p12@worldwarcraft.com','WorldWarcraft'),('2016-01-01 18:00:00','6','100','p13@hearthstone.com','Hearthstone'),('2016-01-01 18:00:00','4','46','p14@menghuanxiyou.com','Menghuanxiyou'),('2016-01-01 18:00:00','3','79','p15@menghuanxiyou.com','Menghuanxiyou'),('2016-01-01 18:00:00','2','88','p16@overwatch.com','Overwatch'),('2016-01-01 18:00:00','4','46','p17@overwatch.com','Overwatch'),('2016-01-01 18:00:00','5','100','p18@overwatch.com','Overwatch'),('2016-01-01 18:00:00','5','79','p1@crossfire.com','Crossfire'),('2016-01-01 18:00:00','3','85','p2@crossfire.com','Crossfire'),('2016-01-01 18:00:00','5','85','p2@hearthstone.com','Hearthstone'),('2016-01-01 18:00:00','3','88','p2@overwatch.com','Overwatch'),('2016-01-01 18:00:00','3','79','p3@crossfire.com','Crossfire'),('2016-01-01 18:00:00','4','88','p4@crossfire.com','Crossfire'),('2016-01-01 18:00:00','4','100','p4@menghuanxiyou.com','Menghuanxiyou'),('2016-01-01 18:00:00','5','46','p5@crossfire.com','Crossfire'),('2016-01-01 18:00:00','6','85','p5@dahuaxiyou.com','Dahuaxiyou'),('2016-01-01 18:00:00','6','79','p6@dahuaxiyou.com','Dahuaxiyou'),('2016-01-01 18:00:00','7','37','p6@worldwarcraft.com','WorldWarcraft'),('2016-01-01 18:00:00','2','100','p7@dahuaxiyou.com','Dahuaxiyou'),('2016-01-01 18:00:00','2',NULL,'p8@dnf.com','DNF'),('2016-01-01 18:00:00','3','75','p9@dnf.com','DNF'),('2016-01-02 18:00:00','4','25','p10@hearthstone.com','Hearthstone'),('2016-01-02 18:00:00','4','37','p11@hearthstone.com','Hearthstone'),('2016-01-02 18:00:00','4','100','p12@menghuanxiyou.com','Menghuanxiyou'),('2016-01-02 18:00:00','6','37','p13@hearthstone.com','Hearthstone'),('2016-01-02 18:00:00','3','75','p14@menghuanxiyou.com','Menghuanxiyou'),('2016-01-02 18:00:00','3','69','p15@menghuanxiyou.com','Menghuanxiyou'),('2016-01-02 18:00:00','2',NULL,'p16@overwatch.com','Overwatch'),('2016-01-02 18:00:00','3','25','p17@overwatch.com','Overwatch'),('2016-01-02 18:00:00','5','69','p1@crossfire.com','Crossfire'),('2016-01-02 18:00:00','3','25','p2@crossfire.com','Crossfire'),('2016-01-02 18:00:00','6','24','p2@hearthstone.com','Hearthstone'),('2016-01-02 18:00:00','2','24','p2@overwatch.com','Overwatch'),('2016-01-02 18:00:00','3','75','p3@crossfire.com','Crossfire'),('2016-01-02 18:00:00','4','37','p4@crossfire.com','Crossfire'),('2016-01-02 18:00:00','4','25','p4@menghuanxiyou.com','Menghuanxiyou'),('2016-01-02 18:00:00','5','37','p5@crossfire.com','Crossfire'),('2016-01-02 18:00:00','6','24','p5@dahuaxiyou.com','Dahuaxiyou'),('2016-01-02 18:00:00','6',NULL,'p6@dahuaxiyou.com','Dahuaxiyou'),('2016-01-02 18:00:00','2','75','p7@dahuaxiyou.com','Dahuaxiyou'),('2016-01-02 18:00:00','2','25','p8@dnf.com','DNF'),('2016-01-02 18:00:00','3','75','p9@dnf.com','DNF'),('2016-01-03 18:00:00','2','69','p16@overwatch.com','Overwatch');
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-08 15:22:58
