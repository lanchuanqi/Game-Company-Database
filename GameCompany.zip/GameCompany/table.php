 <!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>UO Trail High Scores!</title>
    </head>
    <body>
      <?php
      include('connectionData.txt');
$conn = mysqli_connect($server, $user, $pass, $dbname, $port)
or die('Error connecting to MySQL server.');



      //execute the SQL query and return records
      $query =  'SELECT  name, score
                FROM high_scores 
                ORDER BY score DESC LIMIT 10';

        ?>
        <style>
        thead {color:black;}
        </style>
        <h2>UO Trail High Scores!</h2>
         <table cellpadding="5" align ="left" order="3" style= "font-family:arial; width: 20%; background-color: #84ed86; color: #761a9b;" >
      <thead>
       <tr>
        <th align="left">Name</th>
        <th align="left">Score</th>
       </tr>

        </thead>
        <tbody>
        <?php
        $result = mysqli_query($conn, $query)
        or die(mysqli_error($conn));
          while( $row = mysqli_fetch_assoc( $result ) ){

            echo
            "<tr>       
              <td>{$row['name']}</td>
              <td>{$row['score']}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
    <?php mysqli_close($conn); ?>
    </body>
    </html>