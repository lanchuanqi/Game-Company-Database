<?php

include('con_data.txt');


$mysqli = new mysqli($server, $user, $pass, $dbname, $port);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}


?>

<html>
<head>
  <title> CIS 451 Assignment4 </title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
  

$manu_name = $_POST['company_name'];

$manu_name = mysqli_real_escape_string($mysqli, $manu_name);

$query = "SELECT country
FROM game_company
LEFT JOIN
WHERE company_name = ? ";


/* Prepared statement, prepare */
if (!($stmt = $mysqli->prepare($query))) {
     echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
}

/* Prepared statement, bind */
if (!$stmt->bind_param("s", $manu_name)) {
    echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
}
/* Prepared statement, Execute */
if (!$stmt->execute()) {
    echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
}

$result = mysqli_stmt_get_result($stmt);



/* explicit close recommended */
$stmt->close();




?>

<p>
The query:
<p>

<?php

$query = "hahahahahahahahahahahahhahahahaha";

print $query;
echo "<br />\n";
echo "<br />\n";
print "Result: ";
echo "<br />\n";
echo "<br />\n";

while ($row = mysqli_fetch_array($result, MYSQLI_NUM)){
  foreach ($row as $r){
    print "$r ";
  }
  echo "<br />\n";
}

?>

<br>
<br>
<br>
<a href="findCustState.txt" >Contents</a>
of the PHP program that created this page. 	 
 
</body>
</html>
	  
