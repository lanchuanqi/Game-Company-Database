
<?php
include('connectionData.txt');

$mysqli = new mysqli($server, $user, $pass, $dbname2, $port);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

?>



<html>
<head>
  <title> CIS 451 Final Project </title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
$id = $_POST['playerid'];

$id = mysqli_real_escape_string($mysqli, $id);

$query = "SELECT player_id,player_name, account_info, game_name
FROM player
join account using(player_id)
where player_id = ? ";
/* Prepared statement, prepare */
if (!($stmt = $mysqli->prepare($query))) {
     echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
}
/* Prepared statement, bind */
if (!$stmt->bind_param("s", $id)) {
    echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
}
/* Prepared statement, Execute */
if (!$stmt->execute()) {
    echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
}
$result = mysqli_stmt_get_result($stmt);
/* explicit close recommended */
$stmt->close();

$query = "SELECT *
FROM player
WHERE player_id = ";
$query = $query."'".$id."';";
?>


<style>
  thead {color:black;}
</style>
<h2> Player Info!</h2>
<table cellpadding="5" align ="left" order="3" style= "font-family:arial; width: 100%; background-color: gold;">
<thead>
<tr style="background-color:yellowgreen;color:white;">
<th align="left">Player ID</th>
<th align="left">Name</th>
<th align="left">Account Information</th>
<th align="left">Game Name</th>
</tr>
</thead>
<tbody>

<?php
while ($row = mysqli_fetch_array($result)){
  echo
  "<tr>       
      <td>{$row['player_id']}</td>
      <td>{$row['player_name']}</td> 
      <td>{$row['account_info']}</td>
      <td>{$row['game_name']}</td>
  </tr>\n";
}
?>
</tbody>
</table>

<p>
<a href="player.txt" >Contents</a>
of the PHP program that created this page.
</p>


</body>
</html>




