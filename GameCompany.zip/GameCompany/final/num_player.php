
<?php
include('connectionData.txt');

$mysqli = new mysqli($server, $user, $pass, $dbname2, $port);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

?>



<html>
<head>
  <title> CIS 451 Final Project </title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
$query = "select game_name, count(player_id) as number_player
from account
group by game_name
order by number_player desc;";

$result = mysqli_query($mysqli, $query)
or die(mysqli_error($mysqli));
?>


<style>
  thead {color:black;}
</style>
<h2> Number of Players for Game</h2>
<table cellpadding="5" align ="left" order="3" style= "font-family:arial; width: 100%; background-color: gold;">
<thead>
<tr style="background-color:yellowgreen;color:white;">
<th align="left">Game Name</th>
<th align="left">Number of Players</th>

</tr>
</thead>
<tbody>

<?php
while ($row = mysqli_fetch_array($result)){
  echo
  "<tr>       
      <td>{$row['game_name']}</td>
      <td>{$row['number_player']}</td> 

  </tr>\n";
}
?>
</tbody>
</table>

<p>
<a href="num_player.txt" >Contents</a>
of the PHP program that created this page.
</p>


</body>
</html>