
<?php
include('connectionData.txt');

$mysqli = new mysqli($server, $user, $pass, $dbname2, $port);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

?>



<html>
<head>
  <title> CIS 451 Final Project </title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
$query = "select gc.company_name, sum(spend.total_spend) as earned
from game_company gc join department de
using(company_name)
join (select h.game_name as name, sum(h.purchase) AS total_spend , g.dep_name as dep
from history h join game g where g.game_name = h.game_name
group by h.game_name)spend
where de.dep_name = spend.dep
group by company_name;";

$result = mysqli_query($mysqli, $query)
or die(mysqli_error($mysqli));
?>


<style>
  thead {color:black;}
</style>
<h2> Company Income</h2>
<table cellpadding="5" align ="left" order="3" style= "font-family:arial; width: 100%; background-color: gold;">
<thead>
<tr style="background-color:yellowgreen;color:white;">
<th align="left">Company Name</th>
<th align="left">Total Income</th>
</tr>
</thead>
<tbody>

<?php
while ($row = mysqli_fetch_array($result)){
  echo
  "<tr>       
      <td>{$row['company_name']}</td>
      <td>{$row['earned']}</td> 
  </tr>\n";
}
?>
</tbody>
</table>

<p>
<a href="company_earn.txt" >Contents</a>
of the PHP program that created this page.
</p>


</body>
</html>
