
<?php
include('connectionData.txt');

$mysqli = new mysqli($server, $user, $pass, $dbname2, $port);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

?>



<html>
<head>
  <title> CIS 451 Final Project </title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
$query = "select gc.company_name, sum(em.salary) as total_salary
from employee em
join department de
using(dep_name)
left join game_company gc
using(company_name)
group by company_name
order by total_salary desc;
";

$result = mysqli_query($mysqli, $query)
or die(mysqli_error($mysqli));
?>


<style>
  thead {color:black;}
</style>
<h2> Total Salary</h2>
<table cellpadding="5" align ="left" order="3" style= "font-family:arial; width: 100%; background-color: gold;">
<thead>
<tr style="background-color:yellowgreen;color:white;">
<th align="left">Company Name</th>
<th align="left">Total Salary</th>

</tr>
</thead>
<tbody>

<?php
while ($row = mysqli_fetch_array($result)){
  echo
  "<tr>       
      <td>{$row['company_name']}</td>
      <td>{$row['total_salary']}</td> 

  </tr>\n";
}
?>
</tbody>
</table>

<p>
<a href="pay_employee.txt" >Contents</a>
of the PHP program that created this page.
</p>


</body>
</html>