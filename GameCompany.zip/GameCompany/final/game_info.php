
<?php
include('connectionData.txt');

$mysqli = new mysqli($server, $user, $pass, $dbname2, $port);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

?>



<html>
<head>
  <title> CIS 451 Final Project </title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
$query = "select * from game
";

$result = mysqli_query($mysqli, $query)
or die(mysqli_error($mysqli));
?>


<style>
  thead {color:black;}
</style>
<h2> Game Info</h2>
<table cellpadding="5" align ="left" order="3" style= "font-family:arial; width: 100%; background-color: gold;">
<thead>
<tr style="background-color:yellowgreen;color:white;">
<th align="left">Game Name</th>
<th align="left">Game Info</th>
<th align="left">Game Type</th>
<th align="left">Designed by Department</th>

</tr>
</thead>
<tbody>

<?php
while ($row = mysqli_fetch_array($result)){
  echo
  "<tr>       
      <td>{$row['game_name']}</td>
      <td>{$row['game_info']}</td>
      <td>{$row['game_type']}</td>
      <td>{$row['dep_name']}</td> 

  </tr>\n";
}
?>
</tbody>
</table>



<p>
<a href="game_info.txt" >Contents</a>
of the PHP program that created this page.
</p>


</body>
</html>