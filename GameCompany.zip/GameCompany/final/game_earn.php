
<?php
include('connectionData.txt');

$mysqli = new mysqli($server, $user, $pass, $dbname2, $port);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

?>



<html>
<head>
  <title> CIS 451 Final Project </title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
$query = "select h.game_name as name, sum(h.purchase) AS total_earned , g.dep_name as department, de.company_name
from history h 
join game g 
using(game_name)
join department de where g.dep_name = de.dep_name
group by h.game_name;";

$result = mysqli_query($mysqli, $query)
or die(mysqli_error($mysqli));
?>


<style>
  thead {color:black;}
</style>
<h2> Game Income</h2>
<table cellpadding="5" align ="left" order="3" style= "font-family:arial; width: 100%; background-color: gold;">
<thead>
<tr style="background-color:yellowgreen;color:white;">
<th align="left">Game Name</th>
<th align="left">Total Income</th>
<th align="left">Department Name</th>
<th align="left">Company Name</th>
</tr>
</thead>
<tbody>

<?php
while ($row = mysqli_fetch_array($result)){
  echo
  "<tr>       
      <td>{$row['name']}</td>
      <td>{$row['total_earned']}</td> 
      <td>{$row['department']}</td>
      <td>{$row['company_name']}</td> 

  </tr>\n";
}
?>
</tbody>
</table>

<p>
<a href="game_earn.txt" >Contents</a>
of the PHP program that created this page.
</p>


</body>
</html>