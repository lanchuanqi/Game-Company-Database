<?php

include('connectionData.txt');



$mysqli = new mysqli($server, $user, $pass, $dbname2, $port);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

?>

<html>
<head>
  <title> CIS 451 Final Project</title>
  </head>
  
  <body bgcolor="white">
  
  
  <hr>
  
  
<?php
$manu_name = $_POST['manu_name'];

$manu_name = mysqli_real_escape_string($mysqli, $manu_name);

$query = "SELECT *
FROM game_company
WHERE company_name = ? ";
/* Prepared statement, prepare */
if (!($stmt = $mysqli->prepare($query))) {
     echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
}
/* Prepared statement, bind */
if (!$stmt->bind_param("s", $manu_name)) {
    echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
}
/* Prepared statement, Execute */
if (!$stmt->execute()) {
    echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
}
$result = mysqli_stmt_get_result($stmt);
/* explicit close recommended */
$stmt->close();

$query = "SELECT *
FROM game_company
WHERE company_name = ";
$query = $query."'".$manu_name."';";
?>

<style>
  thead {color:black;}
</style>
<h2> Company Info!</h2>
<table cellpadding="5" align ="left" order="3" style= "font-family:arial; width: 100%; background-color: gold;">
<thead>
<tr style="background-color:yellowgreen;color:white;"><th align="left">Company Name</th>
<th align="left">Country</th>
<th align="left">Establish Year</th>
<th align="left">Establish CEO</th>
</tr>
</thead>
<tbody>

<?php
while ($row = mysqli_fetch_array($result)){
    echo
  "<tr>       
      <td>{$row['company_name']}</td>
      <td>{$row['country']}</td>
      <td>{$row['establish_year']}</td> 
      <td>{$row['CEO_name']}</td>
  </tr>\n";
}

?>
</tbody>
</table>

<p>
<a href="game.txt" >Contents</a>
of the PHP program that created this page. 	 
 
</body>
</html>
	  
